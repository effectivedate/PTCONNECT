package com.ptconnect.myapp.domain;

public class AdminDTO {
	
}
