package com.ptconnect.myapp.domain;


public class ProgramDTO extends TrainerInfoDTO{
	
    private String pgContent;

	public String getPgContent() {
		return pgContent;
	}

	public void setPgContent(String pgContent) {
		this.pgContent = pgContent;
	}

	
}


