package com.ptconnect.myapp.domain;


public class QualifyInfo{
	
	private String qualify;

	public String getQualify() {
		return qualify;
	}

	public void setQualify(String qualify) {
		this.qualify = qualify;
	}

}


