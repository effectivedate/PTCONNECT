package com.ptconnect.myapp.domain;

public class NonMemberDTO {
	private int nmNo;
	private String nmName;
	private String nmPhone;
	private String nmPwd;
	private String nmDate;
	private String nmDelYN;
	public int getNmNo() {
		return nmNo;
	}
	public void setNmNo(int nmNo) {
		this.nmNo = nmNo;
	}
	public String getNmName() {
		return nmName;
	}
	public void setNmName(String nmName) {
		this.nmName = nmName;
	}
	public String getNmPhone() {
		return nmPhone;
	}
	public void setNmPhone(String nmPhone) {
		this.nmPhone = nmPhone;
	}
	public String getNmPwd() {
		return nmPwd;
	}
	public void setNmPwd(String nmPwd) {
		this.nmPwd = nmPwd;
	}
	public String getNmDate() {
		return nmDate;
	}
	public void setNmDate(String nmDate) {
		this.nmDate = nmDate;
	}
	public String getNmDelYN() {
		return nmDelYN;
	}
	public void setNmDelYN(String nmDelYN) {
		this.nmDelYN = nmDelYN;
	}
	
	
}
