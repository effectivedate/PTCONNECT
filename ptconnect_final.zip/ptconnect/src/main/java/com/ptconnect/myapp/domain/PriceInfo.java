package com.ptconnect.myapp.domain;


public class PriceInfo{
	
	private String lpCount;
    private String lpCf;
    private String lessonPrice;
    
	public String getLpCount() {
		return lpCount;
	}
	public void setLpCount(String lpCount) {
		this.lpCount = lpCount;
	}
	public String getLpCf() {
		return lpCf;
	}
	public void setLpCf(String lpCf) {
		this.lpCf = lpCf;
	}
	public String getLessonPrice() {
		return lessonPrice;
	}
	public void setLessonPrice(String lessonPrice) {
		this.lessonPrice = lessonPrice;
	}

}


